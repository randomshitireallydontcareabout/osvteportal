1. Extract this ZIP.
2. Open PowerShell in the extracted folder.
3. Run:
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\test.ps1 -Install
4. Return to the OSV web portal and launch Remote Desktop.
